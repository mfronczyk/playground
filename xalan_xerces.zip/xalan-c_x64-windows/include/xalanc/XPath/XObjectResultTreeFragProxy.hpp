/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the  "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#if !defined(XOBJECTRESULTTREEFRAGPROXY_HEADER_GUARD_1357924680)
#define XOBJECTRESULTTREEFRAGPROXY_HEADER_GUARD_1357924680



// Base include file.  Must be first.
#include <xalanc/XPath/XPathDefinitions.hpp>



#include <xalanc/Include/XalanMemoryManagement.hpp>



#include <xalanc/XPath/XObjectResultTreeFragProxyBase.hpp>
#include <xalanc/XPath/XObjectResultTreeFragProxyText.hpp>



namespace XALAN_CPP_NAMESPACE {



class XPathExecutionContext;



class XALAN_XPATH_EXPORT XObjectResultTreeFragProxy : public XObjectResultTreeFragProxyBase
{
public:

    /**
     * Constructor.
     *
     * @param theXObject The XObject instance for which this is a proxy.
     * @param theManager The MemoryManager for this instance.
     * @param theExecutionContext An optional XPathExecutionContext instance.
     */
    XObjectResultTreeFragProxy(
            const XObject&          value,
            MemoryManager&          theManager,
            XPathExecutionContext*  theExecutionContext);

    virtual
    ~XObjectResultTreeFragProxy();


    XPathExecutionContext*
    getExecutionContext()
    {
        return m_proxy.getExecutionContext();
    }

    // These interfaces are inherited from XalanDocumentFragment...

    virtual XalanNode*
    getFirstChild() const;

    virtual XalanNode*
    getLastChild() const;

private:

    // Not implemented...
    XObjectResultTreeFragProxy(const XObjectResultTreeFragProxy&    theSource);

    XObjectResultTreeFragProxy&
    operator=(const XObjectResultTreeFragProxy& theRHS);

    bool
    operator==(const XObjectResultTreeFragProxy&    theRHS);


    // Data members...
    mutable XObjectResultTreeFragProxyText  m_proxy;
};



}



#endif  // XOBJECTRESULTTREEFRAGPROXY_HEADER_GUARD_1357924680
